import express from "express";

import {
  listGrn,
  getGrnById,
  createGrn,
  updateGrn,
  listInwardModels,
  createInwardModel,
  listInwardCompanies,
  createInwardCompany,
} from "../controllers/inwardController.js";

import {
  uploadGrnDocument,
} from "../controllers/documentController.js";

import authenticate from "../middleware/authenticate.js";

import authorize from "../middleware/authorize.js";

import requireWarehouseAccess from "../middleware/requireWarehouseAccess.js";

import {
  upload,
} from "../middleware/uploadMiddleware.js";

const router = express.Router();


// =====================================================
// AUTHENTICATION
// =====================================================

router.use(authenticate);


// =====================================================
// GET ALL GRN
// =====================================================

router.get(
  "/",
  listGrn
);


// =====================================================
// GET ONE GRN
// =====================================================

router.get(
  "/models",
  listInwardModels
);

router.post(
  "/models",
  authorize("SUPER_ADMIN", "WAREHOUSE_MANAGER"),
  createInwardModel
);

router.get(
  "/companies",
  listInwardCompanies
);

router.post(
  "/companies",
  authorize("SUPER_ADMIN", "WAREHOUSE_MANAGER"),
  createInwardCompany
);

router.get(
  "/:id",
  getGrnById
);


// =====================================================
// CREATE GRN
// =====================================================

router.put(
  "/:id",
  authorize("SUPER_ADMIN", "WAREHOUSE_MANAGER"),
  updateGrn
);

router.post(
  "/",
  // "ACCOUNTS_ADMIN" isn't a real role (see Role enum) — that meant
  // SUPER_ADMIN/SUPER_ADMIN could never create a GRN at all.
  authorize(
    "SUPER_ADMIN",
    "SUPER_ADMIN",
    "WAREHOUSE_MANAGER"
  ),
  // Blocks on: warehouse not found, parent company Inactive, this
  // warehouse's own Inward toggle off, or (for WAREHOUSE_MANAGER) no
  // grant / canInward off for this specific user on this warehouse.
  requireWarehouseAccess("canInward", (req) => req.body.warehouseId),
  createGrn
);


// =====================================================
// UPLOAD DOCUMENT TO GRN
// =====================================================

router.post(
  "/:id/documents",
  upload.single("file"),
  uploadGrnDocument
);


export default router;