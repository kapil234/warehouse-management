import prisma from "../config/prisma.js";

const DEFAULT_DOCUMENT_TYPES = ["Delivery challan", "E-way bill", "Dispatch photo"];

async function getScopedWarehouseIds(req) {
  if (req.user.role === "SUPER_ADMIN") return null;
  if (req.user.role === "WAREHOUSE_MANAGER") {
    const rows = await prisma.warehouseAccess.findMany({
      where: { userId: req.user.id, accessLevel: "MANAGE" },
      select: { warehouseId: true },
    });
    return rows.map((r) => r.warehouseId);
  }
  return [];
}

async function assertWarehouseAccess(req, warehouseId, permission = "canOutward") {
  if (!warehouseId) throw Object.assign(new Error("warehouseId is required"), { status: 400 });

  const warehouse = await prisma.warehouse.findUnique({
    where: { id: warehouseId },
    select: { id: true, code: true, companyId: true, Outward: true, company: { select: { status: true } } },
  });
  if (!warehouse) throw Object.assign(new Error("Warehouse not found"), { status: 404 });
  if (warehouse.company?.status === "Inactive") throw Object.assign(new Error("This warehouse belongs to an inactive company."), { status: 403 });
  if (permission === "canOutward" && warehouse.Outward !== "Active") throw Object.assign(new Error("Outward is disabled for this warehouse."), { status: 403 });

  if (req.user.role === "SUPER_ADMIN") return warehouse;

  const access = await prisma.warehouseAccess.findUnique({
    where: { userId_warehouseId: { userId: req.user.id, warehouseId } },
  });
  if (!access || access.accessLevel !== "MANAGE") throw Object.assign(new Error("You don't have access to this warehouse"), { status: 403 });
  if (permission && !access[permission]) throw Object.assign(new Error("You don't have permission to do this on this warehouse"), { status: 403 });
  return warehouse;
}

function documentStatus(documents = []) {
  const required = new Set(DEFAULT_DOCUMENT_TYPES.map((x) => x.toLowerCase()));
  const uploaded = new Set(documents.map((d) => String(d.docCategory || "").toLowerCase()));
  const pendingDocuments = [...required].filter((x) => !uploaded.has(x)).length;
  return {
    status: pendingDocuments === 0 ? "Complete" : "Pending",
    pendingDocuments,
    uploadedDocuments: DEFAULT_DOCUMENT_TYPES.length - pendingDocuments,
    requiredDocuments: DEFAULT_DOCUMENT_TYPES.length,
  };
}

export async function listOutward(req, res) {
  try {
    const { search = "", type, dateFrom, dateTo, warehouseId, page = "1", pageSize = "20" } = req.query;
    const scopedWarehouseIds = await getScopedWarehouseIds(req);
    const where = {
      AND: [
        scopedWarehouseIds ? { warehouseId: { in: scopedWarehouseIds } } : {},
        warehouseId ? { warehouseId } : {},
        search ? { OR: [
          { outwardNumber: { contains: search, mode: "insensitive" } },
          { customerName: { contains: search, mode: "insensitive" } },
          { companyName: { contains: search, mode: "insensitive" } },
          { refDocNumber: { contains: search, mode: "insensitive" } },
        ] } : {},
        type ? { outwardType: type } : {},
        dateFrom || dateTo ? { createdAt: {
          ...(dateFrom ? { gte: new Date(dateFrom) } : {}),
          ...(dateTo ? { lte: new Date(dateTo) } : {}),
        } } : {},
      ],
    };

    const pageNum = Math.max(parseInt(page, 10) || 1, 1);
    const pageSizeNum = Math.min(Math.max(parseInt(pageSize, 10) || 20, 1), 100);
    const [rows, total] = await Promise.all([
      prisma.min.findMany({
        where,
        include: {
          items: true,
          referenceDocuments: true,
          createdBy: { select: { name: true, email: true } },
          warehouse: { select: { id: true, name: true, code: true, company: { select: { name: true } } } },
        },
        orderBy: { createdAt: "desc" },
        skip: (pageNum - 1) * pageSizeNum,
        take: pageSizeNum,
      }),
      prisma.min.count({ where }),
    ]);

    const ids = rows.map((x) => x.id);
    const documents = ids.length ? await prisma.document.findMany({ where: { linkedType: "outward", linkedId: { in: ids } }, orderBy: { uploadedAt: "desc" } }) : [];
    const data = rows.map((row) => {
      const docs = documents.filter((d) => d.linkedId === row.id);
      return { ...row, documents: docs, ...documentStatus(docs) };
    });

    return res.json({ data, pagination: { page: pageNum, pageSize: pageSizeNum, total, totalPages: Math.ceil(total / pageSizeNum) } });
  } catch (error) {
    console.error("List outward error:", error);
    return res.status(500).json({ message: "Failed to fetch outward entries", error: error.message });
  }
}

export async function getOutwardById(req, res) {
  try {
    const min = await prisma.min.findUnique({
      where: { id: req.params.id },
      include: {
        items: true,
        referenceDocuments: true,
        createdBy: { select: { name: true, email: true, role: true } },
        warehouse: { select: { id: true, name: true, code: true, companyId: true, company: { select: { name: true } } } },
      },
    });
    if (!min) return res.status(404).json({ message: "Outward entry not found" });

    // Read access is deliberately warehouse-scoped.
    if (req.user.role === "WAREHOUSE_MANAGER") {
      const access = await prisma.warehouseAccess.findUnique({ where: { userId_warehouseId: { userId: req.user.id, warehouseId: min.warehouseId } } });
      if (!access || access.accessLevel !== "MANAGE") return res.status(403).json({ message: "You don't have access to this entry's warehouse" });
    }

    const documents = await prisma.document.findMany({ where: { linkedType: "outward", linkedId: min.id }, orderBy: { uploadedAt: "desc" } });
    return res.json({ data: { ...min, documents, ...documentStatus(documents) } });
  } catch (error) {
    console.error("Get outward error:", error);
    return res.status(500).json({ message: "Failed to fetch outward entry", error: error.message });
  }
}

export async function listOutwardModels(req, res) {
  try {
    const { warehouseId } = req.query;
    await assertWarehouseAccess(req, warehouseId, null);
    const [catalog, history] = await Promise.all([
      prisma.warehouseModel.findMany({ where: { warehouseId }, orderBy: [{ category: "asc" }, { name: "asc" }] }),
      prisma.minItem.findMany({ where: { min: { warehouseId } }, select: { category: true, sku: true }, distinct: ["category", "sku"] }),
    ]);
    const map = new Map(catalog.map((m) => [`${m.category}::${m.name}`, m]));
    for (const row of history) if (row.sku) map.set(`${row.category}::${row.sku}`, { category: row.category, name: row.sku });
    return res.json({ data: Array.from(map.values()) });
  } catch (error) {
    return res.status(error.status || 500).json({ message: error.message || "Failed to fetch models" });
  }
}

export async function createOutwardModel(req, res) {
  try {
    const { warehouseId, category, name } = req.body;
    await assertWarehouseAccess(req, warehouseId, "canOutward");
    if (!category || !name?.trim()) return res.status(422).json({ message: "category and model name are required" });
    const model = await prisma.warehouseModel.create({ data: { warehouseId, category, name: name.trim() } });
    return res.status(201).json({ data: model });
  } catch (error) {
    if (error.code === "P2002") return res.status(409).json({ message: "This model already exists in this warehouse." });
    return res.status(error.status || 500).json({ message: error.message || "Failed to create model" });
  }
}


export async function updateOutward(req, res) {
  try {
    const { id } = req.params;
    const data = req.body;
    const items = Array.isArray(data.items) ? data.items : [];
    const references = Array.isArray(data.referenceDocuments) ? data.referenceDocuments : [];

    const existing = await prisma.min.findUnique({ where: { id }, select: { id: true, warehouseId: true } });
    if (!existing) return res.status(404).json({ message: "Outward entry not found" });
    await assertWarehouseAccess(req, existing.warehouseId, "canOutward");

    if (!data.outwardType || !data.customerName?.trim() || !data.companyName?.trim()) {
      return res.status(422).json({ message: "Outward type, customer/recipient and company name are required." });
    }
    if (!references.length || !references.some((r) => r?.refDocNumber || r?.ewayBillNumber)) {
      return res.status(422).json({ message: "At least one reference document is required." });
    }
    if (!items.length) return res.status(422).json({ message: "At least one item is required." });
    for (const item of items) {
      if (!item.category || !item.sku?.trim() || Number(item.quantity) <= 0 || !item.uom) {
        return res.status(422).json({ message: "Every item must have category, model, quantity and UOM." });
      }
    }

    const normalizedRefs = references
      .filter((r) => r && (r.refDocNumber || r.ewayBillNumber))
      .map((r) => ({
        refDocType: String(r.refDocType || "Other").trim(),
        refDocNumber: String(r.refDocNumber || r.ewayBillNumber || "N/A").trim(),
        ewayBillNumber: r.ewayBillNumber ? String(r.ewayBillNumber).trim() : null,
      }));

    const result = await prisma.$transaction(async (tx) => {
      await tx.min.update({
        where: { id },
        data: {
          outwardType: data.outwardType,
          customerName: data.customerName.trim(),
          companyName: data.companyName.trim(),
          refDocType: normalizedRefs[0].refDocType,
          refDocNumber: normalizedRefs[0].refDocNumber,
          refDocDate: data.refDocDate ? new Date(data.refDocDate) : new Date(),
          ewayBillNumber: normalizedRefs[0].ewayBillNumber,
          dispatchMode: data.dispatchMode || null,
          vehicleNumber: data.vehicleNumber?.trim() || null,
          remarks: data.remarks?.trim() || null,
          items: {
            deleteMany: {},
            create: items.map((item) => ({
              category: item.category, sku: item.sku.trim(),
              quantity: Number(item.quantity), uom: item.uom,
            })),
          },
          referenceDocuments: {
            deleteMany: {},
            create: normalizedRefs,
          },
        },
      });
      return tx.min.findUnique({ where: { id }, include: { items: true, referenceDocuments: true } });
    });
    return res.json({ message: "Outward entry updated successfully", data: result });
  } catch (error) {
    console.error("Update outward error:", error);
    return res.status(error.status || 500).json({ message: error.message || "Failed to update outward entry" });
  }
}

export async function createOutward(req, res) {
  try {
    const data = req.body;
    const items = Array.isArray(data.items) ? data.items : [];
    const references = Array.isArray(data.referenceDocuments) ? data.referenceDocuments : [];

    const warehouse = await assertWarehouseAccess(req, data.warehouseId, "canOutward");

    if (!data.outwardType) return res.status(422).json({ message: "outwardType is required" });
    if (!data.customerName?.trim()) return res.status(422).json({ message: "customerName is required" });
    if (!data.companyName?.trim()) return res.status(422).json({ message: "companyName is required" });
    if (!data.refDocNumber?.trim() && references.length === 0) return res.status(422).json({ message: "At least one document number is required" });
    if (!items.length) return res.status(422).json({ message: "At least one item is required" });

    for (const item of items) {
      if (!item.category || !item.sku?.trim()) return res.status(422).json({ message: "Each item category and model is required" });
      if (Number(item.quantity) <= 0) return res.status(422).json({ message: `Item "${item.sku}" must have a valid quantity` });
      if (!item.uom) return res.status(422).json({ message: `Item "${item.sku}" UOM is required` });
    }

    const normalizedRefs = (references.length ? references : [{ refDocType: data.refDocType || "Invoice", refDocNumber: data.refDocNumber, ewayBillNumber: data.ewayBillNumber }])
      .filter((r) => r && (r.refDocNumber || r.ewayBillNumber))
      .map((r) => ({ refDocType: String(r.refDocType || "Other").trim(), refDocNumber: String(r.refDocNumber || "").trim(), ewayBillNumber: r.ewayBillNumber ? String(r.ewayBillNumber).trim() : null }));

    if (!normalizedRefs.length) return res.status(422).json({ message: "At least one reference document is required" });

    // Numbering is warehouse-local: MIN-WHCODE-0001, MIN-WHCODE-0002, ...
    const outwardCount = await prisma.min.count({ where: { warehouseId: warehouse.id } });
    let outwardNumber = `MIN-${warehouse.code}-${String(outwardCount + 1).padStart(4, "0")}`;
    let existing = await prisma.min.findUnique({ where: { outwardNumber }, select: { id: true } });
    let sequence = outwardCount + 1;
    while (existing) {
      sequence += 1;
      outwardNumber = `MIN-${warehouse.code}-${String(sequence).padStart(4, "0")}`;
      existing = await prisma.min.findUnique({ where: { outwardNumber }, select: { id: true } });
    }

    const result = await prisma.min.create({
      data: {
        outwardNumber,
        warehouseId: warehouse.id,
        outwardType: data.outwardType,
        customerName: data.customerName.trim(),
        companyName: data.companyName.trim(),
        refDocType: normalizedRefs[0].refDocType,
        refDocNumber: normalizedRefs[0].refDocNumber || normalizedRefs[0].ewayBillNumber || "N/A",
        refDocDate: data.outwardDateTime ? new Date(data.outwardDateTime) : (data.refDocDate ? new Date(data.refDocDate) : new Date()),
        ewayBillNumber: normalizedRefs[0].ewayBillNumber,
        dispatchMode: data.dispatchMode || null,
        vehicleNumber: data.vehicleNumber || null,
        remarks: data.remarks || null,
        createdById: req.user.id,
        items: { create: items.map((item) => ({ category: item.category, sku: item.sku.trim(), quantity: Number(item.quantity), uom: item.uom })) },
        referenceDocuments: { create: normalizedRefs },
      },
      include: { items: true, referenceDocuments: true },
    });

    return res.status(201).json({ message: "Outward entry created successfully", data: { ...result, documents: [], ...documentStatus([]) } });
  } catch (error) {
    console.error("Create outward error:", error);
    return res.status(error.status || 500).json({ message: error.message || "Failed to create outward entry", error: error.message });
  }
}
