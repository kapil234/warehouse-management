import { useState } from "react";

// ---- design tokens (mirrors the HTML version) ----
const colors = {
  bg: "#f4f5f9",
  card: "#ffffff",
  border: "#e7e8f0",
  text: "#1b1d29",
  muted: "#8a8d9c",
  accentOrange: "#f5a623",
  purple: "#8b7ff5", purpleBg: "#efedfe",
  blue: "#3b82f6", blueBg: "#e9f1ff",
  green: "#22b07d", greenBg: "#e6f8ef",
  amber: "#e0a52c", amberBg: "#fdf3e0",
  pink: "#d465b0", pinkBg: "#fbeaf5",
  red: "#e0525c", redBg: "#fce9ea",
};
const radius = "14px";
const shadow = "0 1px 2px rgba(20,20,43,.04), 0 6px 16px rgba(20,20,43,.05)";

const DATE_OPTIONS = ["Last 7 Days", "Last 30 Days", "Last 90 Days", "This Month", "Custom Range"];

const LEDGER = [
  { date: "12 Sep", ref: "GRN-1039", item: "Cotton Fabric Roll", type: "in", qty: 420 },
  { date: "11 Sep", ref: "DC-884", item: "Printed Shirt Pack", type: "out", qty: 180 },
  { date: "11 Sep", ref: "GRN-1038", item: "Denim Fabric Roll", type: "in", qty: 260 },
  { date: "10 Sep", ref: "DC-882", item: "Kids Wear Set", type: "out", qty: 95 },
  { date: "09 Sep", ref: "DC-880", item: "Formal Trousers", type: "out", qty: 140 },
  { date: "08 Sep", ref: "GRN-1035", item: "Silk Fabric Roll", type: "in", qty: 75 },
];

const SUMMARY_CARDS = [
  {
    key: "stock", full: true, color: "purple",
    label: "Total Stock", value: "5,434 units", note: "units on hand",
    icon: (
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12" />
    ),
  },
  {
    key: "transactions", color: "blue",
    label: "Total Transactions", value: "26", note: "in this period",
    icon: <path d="M4 17V7a2 2 0 0 1 2-2h9l5 5v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z M16 3v6h6" />,
  },
  {
    key: "inwards", color: "green",
    label: "Total Inwards", value: "2,910", note: "units received",
    icon: <path d="M12 5v14M19 12l-7 7-7-7" />,
  },
  {
    key: "outwards", color: "amber",
    label: "Total Outwards", value: "4,127", note: "units issued",
    icon: <path d="M12 19V5M5 12l7-7 7 7" />,
  },
  {
    key: "pending", color: "pink",
    label: "Documents Pending", value: "6", note: "3 GRNs, 3 delivery challans",
    icon: <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6M9 13h6M9 17h6" />,
  },
];

function Icon({ children, size = 15 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      {children}
    </svg>
  );
}

function StatCard({ card }) {
  return (
    <div
      style={{
        gridColumn: card.full ? "1 / -1" : undefined,
        background: colors.card,
        border: `1px solid ${colors.border}`,
        borderRadius: radius,
        boxShadow: shadow,
        padding: "16px 18px",
      }}
    >
      <div
        style={{
          width: 30, height: 30, borderRadius: 8,
          display: "flex", alignItems: "center", justifyContent: "center",
          marginBottom: 10,
          background: colors[`${card.color}Bg`],
          color: colors[card.color],
        }}
      >
        <Icon>{card.icon}</Icon>
      </div>
      <div style={{ fontSize: 12.5, color: colors.muted, marginBottom: 6 }}>{card.label}</div>
      <div style={{ fontSize: 22, fontWeight: 700, marginBottom: 3, letterSpacing: "-0.01em" }}>{card.value}</div>
      <div style={{ fontSize: 11.5, color: colors.muted }}>{card.note}</div>
    </div>
  );
}

export default function ReportsPage() {
  const [dateIdx, setDateIdx] = useState(1);

  return (
    <div style={{ fontFamily: "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", background: colors.bg, color: colors.text, minHeight: "100vh" }}>
      {/* Page header */}
      <div style={{ background: "#ffffff", padding: "22px 28px", borderBottom: `1px solid ${colors.border}` }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 14 }}>
          <div>
            <h1 style={{ margin: "0 0 4px", fontSize: 22, fontWeight: 700, letterSpacing: "-0.01em" }}>Reports</h1>
            <p style={{ margin: 0, fontSize: 13, color: colors.muted }}>Delhi Warehouse</p>
          </div>

          <button
            onClick={() => setDateIdx((i) => (i + 1) % DATE_OPTIONS.length)}
            style={{
              display: "flex", alignItems: "center", gap: 8,
              background: "#ffffff", border: `1px solid ${colors.border}`,
              padding: "8px 12px", borderRadius: 9,
              fontSize: 13, color: colors.text, cursor: "pointer",
              boxShadow: shadow,
            }}
          >
            <span style={{ opacity: 0.7 }}>
              <Icon size={14}>
                <rect x="3" y="4" width="18" height="18" rx="2" />
                <path d="M16 2v4M8 2v4M3 10h18" />
              </Icon>
            </span>
            <span>{DATE_OPTIONS[dateIdx]}</span>
            <span style={{ opacity: 0.5, marginLeft: 2 }}>
              <Icon size={12}>
                <path d="M6 9l6 6 6-6" />
              </Icon>
            </span>
          </button>
        </div>
      </div>

      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "22px 28px 60px" }}>
        {/* Stock Ledger feature entry */}
        <div
          onClick={() => alert("Open Stock Ledger Summary")}
          style={{
            background: colors.card, border: `1px solid ${colors.border}`, borderRadius: radius,
            boxShadow: shadow, padding: "16px 18px",
            display: "flex", alignItems: "center", gap: 14, cursor: "pointer", marginBottom: 28,
          }}
        >
          <div style={{ width: 38, height: 38, borderRadius: 10, flex: "none", background: colors.amberBg, color: colors.amber, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon size={18}>
              <path d="M9 2h6a2 2 0 0 1 2 2v16l-5-3-5 3V4a2 2 0 0 1 2-2z" />
            </Icon>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3 style={{ margin: "0 0 3px", fontSize: 14.5, fontWeight: 700 }}>Stock Ledger Summary</h3>
            <p style={{ margin: 0, fontSize: 12.5, color: colors.muted }}>View stock levels, inwards and outwards with detailed ledger.</p>
          </div>
          <div style={{ color: colors.accentOrange, flex: "none" }}>
            <Icon size={16}>
              <path d="M9 18l6-6-6-6" />
            </Icon>
          </div>
        </div>

        {/* Quick summary */}
        <div style={{ fontSize: 12, fontWeight: 700, color: "#6d7086", margin: "0 0 12px" }}>QUICK SUMMARY</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14, marginBottom: 28 }}>
          {SUMMARY_CARDS.map((card) => (
            <StatCard key={card.key} card={card} />
          ))}
        </div>

        {/* Recent ledger entries */}
        <div style={{ fontSize: 12, fontWeight: 700, color: "#6d7086", margin: "0 0 12px" }}>RECENT LEDGER ENTRIES</div>
        <div style={{ background: colors.card, border: `1px solid ${colors.border}`, borderRadius: radius, boxShadow: shadow, overflow: "hidden" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 18px", borderBottom: `1px solid ${colors.border}` }}>
            <h3 style={{ margin: 0, fontSize: 14.5, fontWeight: 700 }}>Latest Transactions</h3>
            <a href="#" style={{ fontSize: 12.5, color: colors.accentOrange, textDecoration: "none", fontWeight: 600 }}>
              Open full ledger
            </a>
          </div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr>
                  {["Date", "Reference", "Item", "Type", "Qty"].map((h, i) => (
                    <th
                      key={h}
                      style={{
                        textAlign: i === 4 ? "right" : "left",
                        fontSize: 11.5, color: colors.muted, fontWeight: 600,
                        padding: "10px 18px", borderBottom: `1px solid ${colors.border}`,
                      }}
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {LEDGER.map((r, i) => (
                  <tr key={r.ref}>
                    <td style={{ padding: "12px 18px", borderBottom: i === LEDGER.length - 1 ? "none" : `1px solid ${colors.border}` }}>{r.date}</td>
                    <td style={{ padding: "12px 18px", borderBottom: i === LEDGER.length - 1 ? "none" : `1px solid ${colors.border}` }}>{r.ref}</td>
                    <td style={{ padding: "12px 18px", borderBottom: i === LEDGER.length - 1 ? "none" : `1px solid ${colors.border}` }}>{r.item}</td>
                    <td style={{ padding: "12px 18px", borderBottom: i === LEDGER.length - 1 ? "none" : `1px solid ${colors.border}` }}>
                      <span
                        style={{
                          display: "inline-block", padding: "3px 9px", borderRadius: 20, fontSize: 11, fontWeight: 600,
                          background: r.type === "in" ? colors.greenBg : colors.redBg,
                          color: r.type === "in" ? colors.green : colors.red,
                        }}
                      >
                        {r.type === "in" ? "Inward" : "Outward"}
                      </span>
                    </td>
                    <td
                      style={{
                        padding: "12px 18px", borderBottom: i === LEDGER.length - 1 ? "none" : `1px solid ${colors.border}`,
                        textAlign: "right", fontVariantNumeric: "tabular-nums", fontWeight: 600,
                      }}
                    >
                      {r.type === "in" ? "+" : "-"}{r.qty}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}