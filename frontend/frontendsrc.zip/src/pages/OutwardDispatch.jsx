import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, ChevronDown, Loader2, Paperclip, Plus, Trash2 } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import {
  fetchOutwardById,
  dispatchOutward,
  rejectOutward,
  downloadItemProof,
  clearCurrentOutward,
  selectCurrentOutward,
  selectOutwardDetailStatus,
  selectOutwardDetailError,
} from "../features/outward/outwardSlice";
import { isReceivingDocCategory, isPlaceholder, paymentStatusLabel, refTypeLabel, refTypeDocument, REQUIRED_DOCUMENTS, MANAGER_REF_TYPES, isAccountRef, isManagerRef, isAccountDocCategory } from "../features/outward/outwardHelpers";
import OutwardDocuments from "../components/OutwardDocuments";
import useSerialScanner from "../components/SerialScanner";
import { buildSerialLines, initialSerialValues, serialPayload, serialProblem } from "../features/outward/serialHelpers";

/**
 * =========================================================
 * DISPATCH DETAILS  (Warehouse manager, Super admin)
 * =========================================================
 * Opens right after the entry is approved. Filled once; after dispatch the Super admin
 * changes everything (dispatch details included) with Update. The manager only
 * sees the item details (category, model, quantity, UOM) and fills the
 * dispatch side: reference documents, dispatch mode, vehicle / AWB number
 * and remarks. Cost, UTR and approval details are never sent to them.
 *
 * Driver name / contact are part of the dispatch details. Every reference document type chosen
 * (Delivery Challan, Return Note, Bilty, Other) opens its own row in the Documents section to upload.
 * After the first dispatch the manager is taken to the receiving details form.
 * =========================================================
 */

const isSuperAdminUser = () => {
  try { return JSON.parse(localStorage.getItem("user"))?.role === "SUPER_ADMIN"; } catch { return false; }
};

const makeId = () => crypto.randomUUID();
const newReference = () => ({ id: makeId(), refDocType: "Delivery Challan", refDocNumber: "" });
const PHONE_RE = /^[0-9+()\-\s]{6,20}$/;
const toLocalInput = (value) => {
  const d = value ? new Date(value) : new Date();
  if (Number.isNaN(d.getTime())) return toLocalInput();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

export default function OutwardDispatch() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { id } = useParams();

  const outward = useSelector(selectCurrentOutward);
  const detailStatus = useSelector(selectOutwardDetailStatus);
  const detailError = useSelector(selectOutwardDetailError);

  const [dispatchDateTime, setDispatchDateTime] = useState(() => toLocalInput());
  const [references, setReferences] = useState([newReference()]);
  const [dispatchMode, setDispatchMode] = useState("By Road");
  const [vehicleNumber, setVehicleNumber] = useState("");
  const [driverName, setDriverName] = useState("");
  const [driverContact, setDriverContact] = useState("");
  const [remarks, setRemarks] = useState("");
  const [saving, setSaving] = useState(false);
  // Documents picked here are sent together with the dispatch details when the form is saved.
  const [stagedDocs, setStagedDocs] = useState([]);
  const submittingRef = useRef(false); // stops the "already dispatched" redirect firing during our own save
  const [filled, setFilled] = useState(false);
  // Serial numbers: one box per Pcs unit (an item of 4 Pcs -> 4 serial numbers).
  const [serialValues, setSerialValues] = useState({});
  const serialsInitFor = useRef(null);
  // Super admin can reject from here (reason required); it then shows Approve again on the details page.
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejecting, setRejecting] = useState(false);

  const inputCls = "w-full rounded-lg border border-gray-300 bg-white px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500 placeholder:text-gray-400";
  const labelCls = "block text-sm font-semibold text-black mb-1.5";

  useEffect(() => {
    if (id) dispatch(fetchOutwardById(id));
    return () => dispatch(clearCurrentOutward());
  }, [dispatch, id]);

  // Prefill once the entry is loaded (editing details that were already saved).
  useEffect(() => {
    if (!outward || filled) return;
    setFilled(true);

    // Only the dispatch side's own references (delivery challan / return note / other).
    // Invoice and e-way bill are added by the account team and shown read-only below.
    const saved = (Array.isArray(outward.referenceDocuments) ? outward.referenceDocuments : []).filter(isManagerRef);
    if (saved.length) {
      setReferences(
        saved.map((r) => ({
          ...newReference(),
          refDocType: r.refDocType || "Delivery Challan",
          refDocNumber: isPlaceholder(r.refDocNumber) ? "" : r.refDocNumber,
        }))
      );
    }
    if (outward.dispatchMode && !isPlaceholder(outward.dispatchMode)) setDispatchMode(outward.dispatchMode);
    setVehicleNumber(outward.vehicleNumber || "");
    setDriverName(outward.driverName || "");
    setDriverContact(outward.driverContact || "");
    setRemarks(outward.remarks || "");
    if (outward.dispatchState === "Dispatched" || outward.workflowStatus === "DISPATCHED") {
      setDispatchDateTime(toLocalInput(outward.refDocDate));
    }
  }, [outward, filled]);

  const updateReference = (rid, field, value) => setReferences((p) => p.map((r) => (r.id === rid ? { ...r, [field]: value } : r)));
  const addReference = () => setReferences((p) => [...p, newReference()]);
  const removeReference = (rid) => setReferences((p) => (p.length === 1 ? p : p.filter((r) => r.id !== rid)));

  // One (optional) upload row for each reference document type that is chosen: Bilty -> Bilty, Return Note -> Return note ...
  const documentSlots = useMemo(() => {
    const slots = [];
    for (const r of references) {
      const slot = refTypeDocument(r.refDocType);
      if (slot && !slots.includes(slot)) slots.push(slot);
    }
    return slots;
  }, [references]);

  const alreadyDispatched = outward?.dispatchState === "Dispatched" || outward?.workflowStatus === "DISPATCHED";
  const superAdmin = isSuperAdminUser();

  const serialLines = useMemo(() => buildSerialLines(outward?.items || []), [outward?.items]);
  // Load saved serial numbers once per entry (later refreshes, e.g. a document upload, must not wipe what is being scanned).
  useEffect(() => {
    if (!outward || outward.id !== id || serialsInitFor.current === id) return;
    serialsInitFor.current = id;
    setSerialValues(initialSerialValues(buildSerialLines(outward.items || []), outward.serials || []));
  }, [outward, id]);
  const serial = useSerialScanner({ items: outward?.items || [], lines: serialLines, values: serialValues, onChange: setSerialValues });

  // After dispatch the Super admin uses Update (the full edit form, dispatch details included).
  // The warehouse manager stays here and can keep updating the dispatch details.
  useEffect(() => {
    if (!submittingRef.current && detailStatus === "succeeded" && outward && outward.id === id && alreadyDispatched && superAdmin) {
      navigate(`/outward/${id}/edit`, { replace: true });
    }
  }, [outward, id, detailStatus, alreadyDispatched, superAdmin, navigate]);

  // Dispatch details only exist once the entry is approved.
  useEffect(() => {
    // Only trust a freshly loaded entry (detailStatus "succeeded"), never a leftover copy from the
    // page the admin just came from - right after approving, the old copy still says "pending approval".
    if (detailStatus === "succeeded" && outward && outward.id === id && superAdmin && ["PENDING_APPROVAL", "REJECTED", "ON_HOLD"].includes(outward.workflowStatus)) {
      toast.info("Approve this entry first, then fill the dispatch details.");
      navigate(`/outward/${id}`, { replace: true });
    }
  }, [outward, id, superAdmin, navigate, detailStatus]);

  const submitReject = async () => {
    if (!rejectReason.trim()) return toast.error("Please give a reason for rejecting.");
    setRejecting(true);
    const result = await dispatch(rejectOutward({ id, remarks: rejectReason.trim() }));
    setRejecting(false);
    if (rejectOutward.rejected.match(result)) return toast.error(result.payload || "Failed to reject.");
    toast.success(result.payload?.message || "Rejected.");
    setRejectOpen(false);
    navigate(`/outward/${id}`, { replace: true });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const refs = references
      .filter((r) => r.refDocNumber.trim())
      .map((r) => ({
        refDocType: r.refDocType,
        refDocNumber: r.refDocNumber.trim(),
      }));
    if (!refs.length) return toast.error("Please enter at least one reference document number.");
    if (!dispatchMode) return toast.error("Please select the dispatch mode.");
    if (driverContact.trim() && !PHONE_RE.test(driverContact.trim())) return toast.error("Please enter a valid driver contact number.");

    // Every Pcs unit needs its own serial number. Entries dispatched before serial numbers existed
    // can still be updated without them (but if some are entered, all must be).
    const serials = serialPayload(serialLines, serialValues);
    const legacyDispatched = alreadyDispatched && !(outward.serials || []).length && serials.length === 0;
    if (!legacyDispatched) {
      const problem = serialProblem(serialLines, serialValues);
      if (problem) return toast.error(problem);
    }

    setSaving(true);
    submittingRef.current = true;

    const result = await dispatch(
      dispatchOutward({
        id,
        files: stagedDocs.map((d) => ({ file: d.file, docCategory: d.docCategory })),
        payload: {
          outwardDateTime: dispatchDateTime,
          dispatchMode,
          vehicleNumber: vehicleNumber.trim() || undefined,
          driverName: driverName.trim() || undefined,
          driverContact: driverContact.trim() || undefined,
          remarks: remarks.trim() || undefined,
          referenceDocuments: refs,
          ...(legacyDispatched ? {} : { serials }),
        },
      })
    );
    setSaving(false);

    if (dispatchOutward.rejected.match(result)) {
      submittingRef.current = false;
      return toast.error(result.payload || "Failed to save dispatch details.");
    }
    if (alreadyDispatched) {
      toast.success("Dispatch details updated.");
      navigate("/outward", { replace: true });
      return;
    }
    // First dispatch: go straight on to the receiving details form.
    toast.success("Dispatched successfully. Please fill the receiving details.");
    navigate(`/outward/${id}/receiving`, { replace: true });
  };

  if (detailStatus === "loading" || (detailStatus === "idle" && !outward) || (outward && outward.id !== id)) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-gray-50 text-gray-600">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Loading outward entry...
      </div>
    );
  }

  // Approval stage (waiting for approval / rejected): no dispatch fields or documents yet.
  if (detailStatus === "succeeded" && superAdmin && ["PENDING_APPROVAL", "REJECTED", "ON_HOLD"].includes(outward?.workflowStatus)) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-gray-50 text-gray-600">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Opening approval...
      </div>
    );
  }

  if (detailError || !outward) {
    return (
      <div className="min-h-dvh bg-gray-50 p-4 sm:p-6">
        <button onClick={() => navigate(-1)} className="mb-6 flex items-center gap-2 text-gray-600"><ArrowLeft size={20} />Back</button>
        <div className="rounded-xl border border-red-200 bg-white p-6 text-red-600">{detailError || "Outward entry not found."}</div>
      </div>
    );
  }

  const items = outward.items || [];
  const accountRefs = (Array.isArray(outward.referenceDocuments) ? outward.referenceDocuments : []).filter(isAccountRef);
  // Super admin also sees the sales side (PI details, payment status, UTR, proof, approval) and can update it.
  const showCost = superAdmin;

  const handleViewProof = (itemId) => {
    dispatch(downloadItemProof({ outwardId: id, itemId })).then((result) => {
      if (downloadItemProof.rejected.match(result)) toast.error(result.payload || "Unable to open the proof file.");
    });
  };

  return (
    <div className="min-h-dvh bg-gray-50 px-4 py-6 md:px-6">
      <div className="mx-auto max-w-4xl">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3 sm:mb-6">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => navigate(-1)} className="text-gray-500 hover:text-gray-800"><ArrowLeft size={22} /></button>
            <div>
              <h1 className="text-base font-semibold text-gray-900 md:text-lg">{superAdmin ? "Outward details" : alreadyDispatched ? "Update dispatch details" : "Dispatch details"}</h1>
              <p className="text-xs text-gray-400">{outward.outwardNumber}</p>
            </div>
          </div>
          {superAdmin && (
            <div className="flex flex-wrap items-center gap-2">
              {!alreadyDispatched && (
                <button type="button" onClick={() => { setRejectReason(""); setRejectOpen(true); }} className="rounded-lg border border-red-200 bg-white px-3 py-2 text-xs font-semibold text-red-600 hover:bg-red-50 sm:text-sm">Reject</button>
              )}
              <button type="button" onClick={() => navigate(`/outward/${id}/edit`)} className="rounded-lg bg-gray-900 px-3 py-2 text-xs font-semibold text-white hover:bg-black sm:text-sm">Update</button>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <section className="rounded-2xl border border-gray-200 bg-white p-5 md:p-6">
            <h2 className="mb-4 text-sm font-semibold text-gray-900">Outward information</h2>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
              <InfoField label="Outward number" value={outward.outwardNumber} />
              <InfoField label="Customer / Recipient" value={outward.customerName} />
              <InfoField label="Company" value={outward.companyName || outward.warehouse?.company?.name} />
              <InfoField label="Outward type" value={outward.outwardType} />
              {showCost && <InfoField label="PI No." value={outward.piNumber} />}
              {showCost && <InfoField label="PI date" value={outward.piDate ? new Date(outward.piDate).toLocaleDateString("en-IN") : "-"} />}
              {showCost && <InfoField label="PI amount" value={outward.piAmount === null || outward.piAmount === undefined ? "-" : Number(outward.piAmount).toLocaleString("en-IN")} />}
              {showCost && <InfoField label="Ship to - Contact person" value={outward.shipToContactPerson} />}
              {showCost && <InfoField label="Ship to - Contact no." value={outward.shipToContactNo} />}
              {showCost && <InfoField label="Ship to - Location" value={outward.shipToLocation} />}
              {showCost && <InfoField label="Bill to - Contact person" value={outward.billToContactPerson} />}
              {showCost && <InfoField label="Bill to - Contact no." value={outward.billToContactNo} />}
              {showCost && <InfoField label="Bill to - Email" value={outward.billToEmail} />}
              <InfoField label="Warehouse" value={outward.warehouse?.name} />
              <InfoField label="Created by" value={outward.createdBy?.name || outward.createdBy?.email} />
              {showCost && <InfoField label="Approved by" value={outward.approvedByName} />}
              {showCost && <InfoField label="Approved on" value={outward.approvedAt ? new Date(outward.approvedAt).toLocaleString("en-IN") : "-"} />}
              {showCost && outward.approvalRemarks && <InfoField label="Approval remarks" value={outward.approvalRemarks} />}
            </div>
          </section>

          <section className="rounded-2xl border border-gray-200 bg-white p-5 md:p-6">
            <h2 className="mb-4 text-sm font-semibold text-gray-900">Dispatch details</h2>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <div><label className={labelCls}>Dispatch date and time</label><input type="datetime-local" value={dispatchDateTime} onChange={(e) => setDispatchDateTime(e.target.value)} className={inputCls} /></div>
              <div>
                <label className={labelCls}>Dispatch mode</label>
                <div className="relative">
                  <select value={dispatchMode} onChange={(e) => setDispatchMode(e.target.value)} className={`${inputCls} appearance-none`}>
                    <option>By Road</option><option>Courier</option><option>Customer Pickup</option>
                  </select>
                  <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                </div>
              </div>
              <div><label className={labelCls}>Vehicle / AWB number</label><input value={vehicleNumber} onChange={(e) => setVehicleNumber(e.target.value)} placeholder="If applicable" className={inputCls} /></div>
              <div><label className={labelCls}>Driver name</label><input value={driverName} onChange={(e) => setDriverName(e.target.value)} placeholder="Enter driver name" className={inputCls} /></div>
              <div><label className={labelCls}>Driver contact</label><input type="tel" inputMode="tel" value={driverContact} onChange={(e) => setDriverContact(e.target.value)} placeholder="Enter driver contact no." className={inputCls} /></div>
            </div>

            <div className="mt-5 flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-700">Reference documents</span>
              <button type="button" onClick={addReference} className="inline-flex items-center gap-1 rounded-md border border-blue-300 bg-white px-2.5 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-50"><Plus size={13} />Add document</button>
            </div>
            <div className="mt-2 space-y-4">
              {references.map((r, index) => (
                <div key={r.id} className="rounded-xl border border-gray-100 bg-gray-50/40 p-3">
                  {references.length > 1 && (
                    <div className="mb-3 flex items-center justify-between">
                      <span className="text-sm font-semibold text-black">Reference document {index + 1}</span>
                      <button type="button" onClick={() => removeReference(r.id)} className="flex items-center gap-1 text-xs text-red-500"><Trash2 size={13} />Remove</button>
                    </div>
                  )}
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div>
                      <label className={labelCls}>Reference doc type</label>
                      <div className="relative">
                        <select value={r.refDocType} onChange={(e) => updateReference(r.id, "refDocType", e.target.value)} className={`${inputCls} appearance-none`}>
                          {MANAGER_REF_TYPES.map((t) => <option key={t}>{t}</option>)}
                        </select>
                        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                      </div>
                    </div>
                    <div><label className={labelCls}>{r.refDocType === "Bilty" ? "Bilty no." : "Reference doc no."}</label><input value={r.refDocNumber} onChange={(e) => updateReference(r.id, "refDocNumber", e.target.value)} placeholder={r.refDocType === "Bilty" ? "Enter bilty number" : "Enter document number"} className={inputCls} /></div>
                  </div>
                </div>
              ))}
            </div>

            {accountRefs.length > 0 && (
              <div className="mt-5 border-t pt-4">
                <span className="text-xs font-semibold text-gray-700">Added by the account team</span>
                <div className="mt-2 overflow-x-auto rounded-lg border">
                  <table className="w-full text-[11px] sm:text-sm">
                    <thead>
                      <tr className="border-b bg-gray-50 text-left text-gray-500">
                        <th className="px-3 py-2">Document type</th>
                        <th className="px-3 py-2">Reference no.</th>
                      </tr>
                    </thead>
                    <tbody>
                      {accountRefs.map((r, i) => (
                        <tr key={r.id || i} className="border-b last:border-0">
                          <td className="px-3 py-2">{refTypeLabel(r.refDocType)}</td>
                          <td className="px-3 py-2">{r.refDocNumber || "-"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </section>

          <section className="rounded-2xl border border-gray-200 bg-white p-5 md:p-6">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-semibold text-gray-900">Item details</h2>
              {serial.badge}
            </div>
            <div className="overflow-x-auto rounded-lg border">
              <table className={`w-full text-xs sm:text-sm ${showCost ? "min-w-[680px]" : ""}`}>
                <thead>
                  <tr className="border-b bg-gray-50 text-left text-gray-500">
                    <th className="px-1.5 py-2 sm:px-3">#</th>
                    <th className="px-1.5 py-2 sm:px-3">Category</th>
                    <th className="px-1.5 py-2 sm:px-3">Model</th>
                    <th className="px-1.5 py-2 sm:px-3">Qty</th>
                    <th className="px-1.5 py-2 sm:px-3">UOM</th>
                    {serial.hasSerials && <th className="hidden px-3 py-2 sm:table-cell">SR. No</th>}
                    {showCost && (
                      <>
                        <th className="px-3 py-2">Payment status</th>
                        <th className="px-3 py-2">Approve By</th>
                        <th className="px-3 py-2">UTR</th>
                        <th className="px-3 py-2">Proof</th>
                      </>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, index) => (
                    <Fragment key={item.id || index}>
                    <tr className={`${serial.hasSerials ? "border-b-0 sm:border-b" : "border-b"} text-xs last:border-0 sm:text-sm`}>
                      <td className="px-1.5 py-2 sm:px-3">{index + 1}</td>
                      <td className="px-1.5 py-2 sm:px-3">{item.category || "-"}</td>
                      <td className="whitespace-nowrap px-1.5 py-2 font-medium sm:px-3">{item.sku || "-"}</td>
                      <td className="px-1.5 py-2 sm:px-3">{item.quantity}</td>
                      <td className="px-1.5 py-2 sm:px-3">{item.uom || "-"}</td>
                      {serial.hasSerials && <td className="hidden px-3 py-1 align-middle sm:table-cell">{serial.inputCell(item, index)}</td>}
                      {showCost && (
                        <>
                          <td className="px-3 py-2">{paymentStatusLabel(item.paymentStatus)}</td>
                          <td className="px-3 py-2 break-all">{item.approvedBy || "-"}</td>
                          <td className="px-3 py-2 break-all">{item.utrNumber || "-"}</td>
                          <td className="px-3 py-2">
                            {item.hasProof ? (
                              <button type="button" onClick={() => handleViewProof(item.id)} className="inline-flex items-center gap-1 text-blue-700 hover:underline"><Paperclip size={13} /> View</button>
                            ) : "-"}
                          </td>
                        </>
                      )}
                    </tr>
                    {serial.hasSerials && serial.mobileInputRow(item, index, 5 + 1 + (showCost ? 4 : 0))}
                    {serial.hasSerials && serial.listRow(item, index, 5 + 1 + (showCost ? 4 : 0))}
                    </Fragment>
                  ))}
                </tbody>
              </table>
            </div>
            {serial.hasSerials && <p className="mt-2 text-xs text-gray-500">Type the serial no. and press Enter or Add, tap Scan to use the camera, or just scan with a connected Bluetooth / Wi-Fi / USB scanner. Each serial no. is listed under its item.</p>}
          </section>

          {serial.camera}

          <OutwardDocuments
            outwardId={id}
            documents={(outward.documents || []).filter((d) => !isReceivingDocCategory(d.docCategory))}
            canManage
            requiredDocuments={[]}
            showSummary={false}
            optionalDocuments={documentSlots}
            addMenuTypes={[...REQUIRED_DOCUMENTS, "Bilty", "Return note", "Other"]}
            subtitle="One row for each reference document above. Upload, download, replace or delete documents."
            deferred={!alreadyDispatched}
            stagedFiles={stagedDocs}
            onStagedChange={setStagedDocs}
            // Invoice / e-way bill documents come from the account team: the manager can download them, not change them.
            isLocked={(category) => !superAdmin && isAccountDocCategory(category)}
          />

          <section className="rounded-2xl border border-gray-200 bg-white p-5 md:p-6">
            <label className={labelCls}>Dispatch remarks</label>
            <textarea rows={3} value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Package condition, dispatch notes, etc." className={`${inputCls} resize-none`} />
          </section>

          <button type="submit" disabled={saving} className="w-full rounded-lg bg-gray-900 py-3 text-sm font-semibold text-white hover:bg-black disabled:opacity-40">
            {saving ? "Saving..." : alreadyDispatched ? "Update dispatch details" : "Save and mark as dispatched"}
          </button>
        </form>
      </div>

      {rejectOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-black/40 px-4">
          <div className="w-full max-w-md rounded-2xl bg-white p-5 shadow-xl">
            <h3 className="text-base font-semibold text-gray-900">Reject this outward entry?</h3>
            <p className="mt-1 text-sm text-gray-500">It becomes Rejected. You can approve it again, or Sales can fix the details and send it again.</p>
            <label className="mt-4 mb-1.5 block text-sm font-semibold text-black">Reason for rejecting</label>
            <textarea rows={3} value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="Tell Sales what needs to be corrected" className="w-full resize-none rounded-lg border border-gray-300 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-blue-500" />
            <div className="mt-4 flex justify-end gap-2">
              <button type="button" disabled={rejecting} onClick={() => setRejectOpen(false)} className="rounded-lg border border-gray-200 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50">Cancel</button>
              <button type="button" disabled={rejecting} onClick={submitReject} className="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700 disabled:opacity-50">{rejecting ? "Please wait..." : "Reject"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function InfoField({ label, value }) {
  return (
    <div className="min-w-0">
      <div className="mb-1 text-xs text-gray-500">{label}</div>
      <div className="break-words text-sm font-medium text-gray-900">{value || "-"}</div>
    </div>
  );
}
